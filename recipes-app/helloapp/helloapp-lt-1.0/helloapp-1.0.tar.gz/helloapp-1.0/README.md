hellapp
=======

Example Yocto/OpenEmbedded autotooled recipe, building an executable Hello, World example.

